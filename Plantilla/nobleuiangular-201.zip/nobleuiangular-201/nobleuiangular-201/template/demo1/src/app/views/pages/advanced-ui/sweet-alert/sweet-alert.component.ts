import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sweet-alert',
  templateUrl: './sweet-alert.component.html'
})
export class SweetAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
