import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feather',
  templateUrl: './feather.component.html',
  styleUrls: ['./feather.component.scss']
})
export class FeatherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
